# Reverse Proxy

## Deploying

### Docker

Building the Container Image

```bash
docker build -t reverse-proxy:latest .
```